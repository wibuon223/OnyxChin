import React from 'react'
import { createRoot } from 'react-dom/client'
import App from './App'
import './index.css'

const container = document.getElementById('root')

if (!container) {
  throw new Error('Element #root tidak ditemukan di index.html')
}

createRoot(container).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
)
